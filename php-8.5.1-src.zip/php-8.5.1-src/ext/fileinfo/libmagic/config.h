#include "php.h"
#include "php_libmagic.h"

#ifndef HAVE_STDINT_H
#define HAVE_STDINT_H 1
#endif

#ifndef HAVE_STDINT_H
#define HAVE_STDINT_H 1
#endif

#ifndef HAVE_VISIBILITY
# ifdef HAVE_FUNC_ATTRIBUTE_VISIBILITY
#  define HAVE_VISIBILITY 1
# else
#  define HAVE_VISIBILITY 0
# endif
#endif
