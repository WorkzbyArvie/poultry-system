timelib
=======

Timelib is a timezone and date/time library that can calculate local time,
convert between timezones and parse textual descriptions of date/time
information.

It is the library supporting PHP's Date/Time extension and MongoDB's time zone
support.

Build Requirements
------------------

On Debian: ``apt install libcpputest-dev re2c``
